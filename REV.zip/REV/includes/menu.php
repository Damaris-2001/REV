

    <!--INICIO DE MENU-->
    <!--menu superior-->
    <header class="header">
		<div class="container">
		<div class="btn-menu">
			<label for="btn-menu">
				<img src="../iconos/menu.svg" alt="Menu">
			</label>
		</div>
			<div class="logo">
				<nav class="logo">
                    <a href="../index.php">
						<img src="../imagenes/Nombre-de-empresa.png" class="logo-imagen">
					</a>
                </nav>
			</div>
			<nav class="menu">
				<a href="../info_menu_superior/lo_que_somos.php">Lo que somos</a>
				<a href="../info_menu_superior/en_lo_que_creemos.php">En lo que creemos</a>
				<a href="../info_menu_superior/lo_que_hacemos.php">Lo que hacemos</a>
				<a href="../info_menu_superior/contacto.php">Contacto</a>
			</nav>
		</div>
	</header>

	<!--menu lateral izquierdo-->
    <input type="checkbox" id="btn-menu">
    <div class="container-menu">
	    <div class="cont-menu">
            <nav>
			    <a href="../info_menu_lateral/otro-servicio.php">Servicios</a>
			    <a href="../info_menu_lateral/galeria_revolutio.php">Galería Revolutio</a>
			    <a href="../info_menu_lateral/siguenos.php">Siguenos</a>
			    <a href="#">F</a>
			    <a href="#">F</a>
		    </nav>
            <label for="btn-menu">
				<img src="../iconos/close outline_.svg" alt="Close">
			</label>
	    </div>
    </div>
    <!--FIN DE MENU-->
