<!DOCTYPE html>
<html lang="en">
<head>

    <?php include ('./includes/headers.php'); ?>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="./includes/menu.css">

    
</head>
<body>
    <main>
        
        <?php include ('./includes/menu_index.php'); ?>
        
		<section class="logo-titulo">
            <div class="logo-empresa">
                <img src="./imagenes/logo_horizontal_azul2x.png" alt="" class="logo-empresa">
				<h2>Todo lo que le ocurra a la tierra les ocurrirá a los hijos de la tierra.
					El hombre no tejió la trama de la vida; él es solo un hilo. Lo que hace con la trama, se lo hace a 
					sí mismo.</h2>
            </div>
        </section>
	</main>
</body>
</html>